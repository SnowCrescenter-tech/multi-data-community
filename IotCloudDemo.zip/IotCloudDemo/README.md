@version 1.0 2025-01-08

@Author Holmes Amzish

物联网云平台接入课程设计。

本项目利用了Java语言编写，框架有Springboot，MyBatis。