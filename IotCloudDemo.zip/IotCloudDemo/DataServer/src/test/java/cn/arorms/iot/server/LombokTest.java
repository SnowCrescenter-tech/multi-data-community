package cn.arorms.iot.server;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LombokTest {
    public static void main(String[] args) {
        log.info("Lombok is working!");
    }
}
